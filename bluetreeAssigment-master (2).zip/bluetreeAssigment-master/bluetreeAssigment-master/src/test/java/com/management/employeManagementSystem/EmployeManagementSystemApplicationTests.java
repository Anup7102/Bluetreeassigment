package com.management.employeManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
